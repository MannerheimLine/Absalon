-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Янв 21 2021 г., 13:30
-- Версия сервера: 8.0.19
-- Версия PHP: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `absalon`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cards_on_edit`
--

CREATE TABLE `cards_on_edit` (
  `id` int UNSIGNED NOT NULL COMMENT 'id - записи',
  `card_id` char(36) NOT NULL COMMENT 'id карты',
  `account_id` char(36) NOT NULL COMMENT 'id пользователя',
  `blocked_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'время когда была заблокирована карта'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Карты которые в данный момент редактируются';

--
-- Дамп данных таблицы `cards_on_edit`
--

INSERT INTO `cards_on_edit` (`id`, `card_id`, `account_id`, `blocked_at`) VALUES
(2, '495305f8-98a2-4aa8-abc7-4a90bae14ddd', 'a69f726c-2677-4bc4-820c-dfd03fff9b3f', '2020-12-20 12:43:34'),
(3, '495305f8-98a2-4aa8-abc7-4a90bae14ddd', 'a69f726c-2677-4bc4-820c-dfd03fff9b3f', '2020-12-20 12:48:09');

-- --------------------------------------------------------

--
-- Структура таблицы `districts`
--

CREATE TABLE `districts` (
  `id` smallint UNSIGNED NOT NULL COMMENT 'id - записи',
  `district_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'имя района',
  `region` tinyint UNSIGNED NOT NULL COMMENT 'id региона'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица с данными о районах';

--
-- Дамп данных таблицы `districts`
--

INSERT INTO `districts` (`id`, `district_name`, `region`) VALUES
(1, 'Анучинский Район', 25),
(2, 'Дальнегорский городской округ', 25),
(3, 'Дальнереченский Район', 25),
(4, 'Кавалеровский Район', 25),
(5, 'Кировский Район', 25),
(6, 'Красноармейский Район', 25),
(7, 'Лазовский Район', 25),
(8, 'Лесозаводский городской округ', 25),
(9, 'Михайловский Район', 25),
(10, 'Надеждинский Район', 25),
(11, 'Октябрьский Район', 25),
(12, 'Ольгинский Район', 25),
(13, 'Партизанский Район', 25),
(14, 'Пограничный Район', 25),
(15, 'Пожарский Район', 25),
(16, 'Спасский городской округ', 25),
(17, 'Тернейский Район', 25),
(18, 'Уссурйиский городской округ', 25),
(19, 'Ханкайский Район', 25),
(20, 'Хасанский Район', 25),
(21, 'Хорольский Район', 25),
(22, 'Черниговский Район', 25),
(23, 'Чугуевский Район', 25),
(24, 'Шкотовский Район', 25),
(25, 'Яковлевский Район', 25);

-- --------------------------------------------------------

--
-- Структура таблицы `genders`
--

CREATE TABLE `genders` (
  `id` tinyint UNSIGNED NOT NULL COMMENT 'id - Записи',
  `gender_name` varchar(10) NOT NULL COMMENT 'системное имя',
  `description` varchar(10) NOT NULL COMMENT 'описание'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица с полом';

--
-- Дамп данных таблицы `genders`
--

INSERT INTO `genders` (`id`, `gender_name`, `description`) VALUES
(1, 'male', 'мужчина'),
(2, 'female', 'женщина');

-- --------------------------------------------------------

--
-- Структура таблицы `insurance_companies`
--

CREATE TABLE `insurance_companies` (
  `id` tinyint UNSIGNED NOT NULL COMMENT 'id - записи',
  `insurance_company_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'название страховой компании',
  `insurer_code` char(2) NOT NULL COMMENT 'код страховщика'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица с названиями страховых организаций';

--
-- Дамп данных таблицы `insurance_companies`
--

INSERT INTO `insurance_companies` (`id`, `insurance_company_name`, `insurer_code`) VALUES
(1, 'Восточной страховой альянс', '11'),
(2, 'Спасские ворота', '16');

-- --------------------------------------------------------

--
-- Структура таблицы `localities`
--

CREATE TABLE `localities` (
  `id` int UNSIGNED NOT NULL COMMENT 'id - записи',
  `locality_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'название населенного пункта',
  `district` smallint UNSIGNED NOT NULL COMMENT 'район'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица с названиями населенных пунктов';

--
-- Дамп данных таблицы `localities`
--

INSERT INTO `localities` (`id`, `locality_name`, `district`) VALUES
(1, 'Антоновка', 23),
(2, 'Архиповка', 23),
(3, 'Березовка', 23),
(4, 'Булыга-Фадеево', 23),
(5, 'Варпаховка', 23),
(6, 'Верхняя Бреевка', 23),
(7, 'Заветное', 23),
(8, 'Заметное', 23),
(9, 'Извилинка', 23),
(10, 'Изюбринный', 23),
(11, 'Каменка', 23),
(12, 'Кокшаровка', 23),
(13, 'Ленино', 23),
(14, 'Лесогорье', 23),
(15, 'Медвежий Кут', 23),
(16, 'Михайловка', 23),
(17, 'Нижние Лужки', 23),
(18, 'Новомихайловка', 23),
(19, 'Новочугуевка', 23),
(20, 'Окраинка', 23),
(21, 'Павловка', 23),
(22, 'Полыниха', 23),
(23, 'Пшеницино', 23),
(24, 'Самарка', 23),
(25, 'Саратовка', 23),
(26, 'Соколовка', 23),
(27, 'Тополевый', 23),
(28, 'Уборка', 23),
(29, 'Цветкова', 23),
(30, 'Чугуевка', 23),
(31, 'Шумный', 23),
(32, 'Ясное', 23);

-- --------------------------------------------------------

--
-- Структура таблицы `patient_cards`
--

CREATE TABLE `patient_cards` (
  `id` char(36) NOT NULL COMMENT 'uuid записи',
  `card_number` int UNSIGNED NOT NULL COMMENT 'номер карты пациента, не уникален',
  `surname` varchar(50) NOT NULL COMMENT 'фамилия',
  `first_name` varchar(50) NOT NULL COMMENT 'имя',
  `second_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'отчество',
  `gender` tinyint UNSIGNED NOT NULL DEFAULT '1' COMMENT 'пол',
  `date_birth` date NOT NULL DEFAULT '1900-01-01' COMMENT 'дата рождения',
  `date_death` date DEFAULT NULL COMMENT 'дата смерти',
  `is_alive` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'статус 1- жив, 2 - мертв',
  `phone_number` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'номер телефона',
  `email` varchar(100) DEFAULT NULL COMMENT 'адрес электронной почты',
  `policy_number` char(16) NOT NULL COMMENT 'номер полиса',
  `insurance_company_id` tinyint UNSIGNED DEFAULT NULL COMMENT 'id страховой компании',
  `insurance_certificate` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'снилс',
  `passport_serial` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'серия паспорта',
  `passport_number` char(6) DEFAULT NULL COMMENT 'номер паспорта',
  `passport_date_of_issue` date DEFAULT NULL COMMENT 'дата выдачи паспорта',
  `fms_department` varchar(255) DEFAULT NULL COMMENT 'отдел УФМС выдавший паспорт',
  `birth_certificate_serial` char(6) DEFAULT NULL COMMENT 'серия свидетельства о рождении',
  `birth_certificate_number` char(6) DEFAULT NULL COMMENT 'номер свидетельства о рождении',
  `birth_certificate_date_of_issue` date DEFAULT NULL COMMENT 'дата выдачи свидетельства о рождении',
  `registry_office` varchar(255) DEFAULT NULL COMMENT 'отдел ЗАГС выдавший свидетельство',
  `region_id` tinyint UNSIGNED NOT NULL DEFAULT '25' COMMENT 'id региона',
  `district_id` smallint UNSIGNED NOT NULL DEFAULT '23' COMMENT 'id района',
  `locality_id` int UNSIGNED NOT NULL DEFAULT '30' COMMENT 'id населенного пункта',
  `street_id` int UNSIGNED DEFAULT NULL COMMENT 'id улицы',
  `house_number` char(5) DEFAULT NULL COMMENT 'номер дома',
  `apartment` char(5) DEFAULT NULL COMMENT 'номер квартиры',
  `workplace` varchar(100) DEFAULT NULL COMMENT 'место работы',
  `profession` varchar(100) DEFAULT NULL COMMENT 'профессия',
  `notation` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'примечание к карте',
  `last_update` datetime DEFAULT NULL COMMENT 'время последнего обновления карты',
  `owner` char(36) DEFAULT NULL COMMENT 'аккаунт пользователя заблокировавший карту',
  `blocked_at` datetime DEFAULT NULL COMMENT 'дата и время блокировки'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица которая будет хранить данные по картам пациентов';

--
-- Дамп данных таблицы `patient_cards`
--

INSERT INTO `patient_cards` (`id`, `card_number`, `surname`, `first_name`, `second_name`, `gender`, `date_birth`, `date_death`, `is_alive`, `phone_number`, `email`, `policy_number`, `insurance_company_id`, `insurance_certificate`, `passport_serial`, `passport_number`, `passport_date_of_issue`, `fms_department`, `birth_certificate_serial`, `birth_certificate_number`, `birth_certificate_date_of_issue`, `registry_office`, `region_id`, `district_id`, `locality_id`, `street_id`, `house_number`, `apartment`, `workplace`, `profession`, `notation`, `last_update`, `owner`, `blocked_at`) VALUES
('225567b1-e3f8-4a2e-bd3a-dfc361cca2f8', 4, 'Иванов', 'Андрей', 'Филимонович', 1, '1992-05-15', '2020-12-09', 2, '', '', '2111122244442231', 1, '22222242132', '', '', NULL, '', '', '', NULL, '', 25, 23, 30, NULL, '', '', '', '', 'Информация 1  2 3 4 5 6 7 8 9 Информация 1  2 3 4 5 6 7 8 9 Информация 1  2 3 4 5 6 7 8 9 Информация 1  2 3 4 5 6 7 8 9', '2021-01-21 12:51:51', NULL, NULL),
('495305f8-98a2-4aa8-abc7-4a90bae14ddd', 1, 'Иванов', 'Юрий', 'Валерьевич', 1, '1994-01-07', NULL, 1, '84237221-1-31', 'ivanovmailru', '1234432156764322', 1, '12332145622', '0505', '321432', '2010-01-07', 'Отдел УФМС по приморскому краю в Чугуевском районе', 'III-ГА', '654252', '1994-01-10', 'Отдел ЗАГС г Артема', 25, 23, 30, 1, '22А', '11', 'Чугуевский леспромхоз', 'Плотник', 'Информация', '2021-01-09 05:58:25', NULL, NULL),
('6f3c4d43-8727-41ce-b6fa-446e46ff1070', 7, 'Иванов7', 'Алексей', 'Семенович', 1, '1994-02-15', '2021-01-06', 1, '', '', '2222223344142231', NULL, '23222212132', '', '', NULL, '', '', '', NULL, '', 25, 23, 30, NULL, '', '', '', '', '', '2021-01-19 14:54:48', NULL, NULL),
('9f0f2487-55e2-410c-b362-858560e44211', 2, 'Иванов3', 'Валерий', 'Филлипович', 1, '1992-01-31', NULL, 1, '', '', '2211122244442232', NULL, '12222342132', '', '', NULL, '', '', '', NULL, '', 25, 23, 30, NULL, '', '', '', '', '', '2021-01-19 15:14:40', NULL, NULL),
('b2e61ed8-b024-4187-88ba-168ae42608ad', 5, 'Иванов4', 'Петр', '', 2, '1993-05-15', NULL, 1, '', '', '2111122244142231', NULL, '21222242132', '', '', NULL, '', '', '', NULL, '', 25, 23, 30, NULL, '', '', '', '', '', '2021-01-20 00:53:20', NULL, NULL),
('c0222a01-ca76-45d0-95db-8a03cbb1554e', 3, 'Иванов5', 'Семен', NULL, 1, '1992-03-31', NULL, 1, NULL, NULL, '2111122244442232', NULL, '22222342132', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 25, 23, 30, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('e2a6fe52-1d4f-47a5-b797-266b7f58ee4e', 6, 'Иванов6', 'Петр', NULL, 1, '1994-01-15', NULL, 1, NULL, NULL, '2111112244142231', NULL, '21222212132', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 25, 23, 30, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `refresh_tokens`
--

CREATE TABLE `refresh_tokens` (
  `id` smallint UNSIGNED NOT NULL COMMENT 'id - записи',
  `account_id` char(36) NOT NULL COMMENT 'uuid учетной записи',
  `refresh_token` char(36) NOT NULL COMMENT 'токен',
  `created` int UNSIGNED NOT NULL COMMENT 'время создания токена в UNIX формате',
  `expires` int UNSIGNED NOT NULL COMMENT 'время окончания действия токена'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица с refresh токенами для ре-аутентификации';

--
-- Дамп данных таблицы `refresh_tokens`
--

INSERT INTO `refresh_tokens` (`id`, `account_id`, `refresh_token`, `created`, `expires`) VALUES
(960, 'a69f726c-2677-4bc4-820c-dfd03fff9b3f', '37e62e4d-2bdb-4627-9ab5-23d78fbf3790', 1611224801, 1613816801);

-- --------------------------------------------------------

--
-- Структура таблицы `regions`
--

CREATE TABLE `regions` (
  `id` tinyint UNSIGNED NOT NULL COMMENT 'id - записи',
  `region_number` varchar(3) NOT NULL COMMENT 'номер региона',
  `region_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'имя региона'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица с регионами России';

--
-- Дамп данных таблицы `regions`
--

INSERT INTO `regions` (`id`, `region_number`, `region_name`) VALUES
(1, '01', 'Республика Адыгея'),
(2, '02', 'Башкортостан Республика'),
(3, '03', ' Бурятия Республика'),
(4, '04', 'Алтай Республика'),
(5, '05', 'Дагестан Республика'),
(6, '06', 'Ингушетия Республика'),
(7, '07', 'Кабардино-Балкарская Республика'),
(8, '08', 'Калмыкия Республика'),
(9, '09', 'Карачаево-Черкесская Республика'),
(10, '10', 'Карелия Республика'),
(11, '11', 'Коми Республика'),
(12, '12', 'Марий Эл Республика'),
(13, '13', 'Мордовия Республика'),
(14, '14', 'Саха /Якутия/ Республика'),
(15, '15', 'Северная Осетия - Алания Республика'),
(16, '16', 'Татарстан Республика'),
(17, '17', 'Тыва Республика'),
(18, '18', 'Удмуртская Республика'),
(19, '19', 'Хакасия Республика'),
(20, '20', 'Чеченская Республика'),
(21, '21', 'Чувашская Республика - Чувашия'),
(22, '22', 'Алтайский Край'),
(23, '23', 'Краснодарский Край'),
(24, '24', 'Красноярский Край'),
(25, '25', 'Приморский Край');

-- --------------------------------------------------------

--
-- Структура таблицы `streets`
--

CREATE TABLE `streets` (
  `id` int UNSIGNED NOT NULL COMMENT 'id - записи',
  `street_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'название улицы'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица с названиями улиц';

--
-- Дамп данных таблицы `streets`
--

INSERT INTO `streets` (`id`, `street_name`) VALUES
(1, '50 лет Октября'),
(2, 'Алексея Лапика'),
(3, 'Арсеньева'),
(4, 'Банивура'),
(5, 'Бархатная'),
(6, 'Береговая'),
(7, 'Весенняя'),
(8, 'Восточная'),
(9, 'Всеволода Сибирцева'),
(10, 'Высокая'),
(11, 'Горный переулок'),
(12, 'Шоферская');

-- --------------------------------------------------------

--
-- Структура таблицы `user_accounts`
--

CREATE TABLE `user_accounts` (
  `id` char(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'uuid учетной записи',
  `user_name` char(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'имя пользователя',
  `password_hash` char(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'хэш от пароля',
  `secret_key` char(40) DEFAULT NULL COMMENT 'секретный ключ',
  `email` varchar(255) NOT NULL COMMENT 'адрес электронной почты',
  `created` date NOT NULL COMMENT '	дата создания учетной записи',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'указывает на последнее обновление сделанное с этой учетной записью'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица с аккаунтами пользователей';

--
-- Дамп данных таблицы `user_accounts`
--

INSERT INTO `user_accounts` (`id`, `user_name`, `password_hash`, `secret_key`, `email`, `created`, `updated`) VALUES
('a69f726c-2677-4bc4-820c-dfd03fff9b3f', 'Mikki', '$2y$12$6fqLeiNwWGZcVBUIa2G3n.H56eDtuvhu44QABz0PvsPD/qtbfTxFm', 'c4a27a64968a457453fbe3c56c7ae0881d793bb3', '', '2020-12-19', '2020-12-19 10:16:01');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cards_on_edit`
--
ALTER TABLE `cards_on_edit`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `region` (`region`);

--
-- Индексы таблицы `genders`
--
ALTER TABLE `genders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `insurance_companies`
--
ALTER TABLE `insurance_companies`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `localities`
--
ALTER TABLE `localities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `district` (`district`);

--
-- Индексы таблицы `patient_cards`
--
ALTER TABLE `patient_cards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `policy_number` (`policy_number`),
  ADD UNIQUE KEY `insurance_certificate` (`insurance_certificate`),
  ADD KEY `district_id` (`district_id`),
  ADD KEY `region_id` (`region_id`),
  ADD KEY `locality_id` (`locality_id`),
  ADD KEY `street_id` (`street_id`),
  ADD KEY `insurance_company_id` (`insurance_company_id`),
  ADD KEY `owner` (`owner`),
  ADD KEY `gender` (`gender`);

--
-- Индексы таблицы `refresh_tokens`
--
ALTER TABLE `refresh_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `streets`
--
ALTER TABLE `streets`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user_accounts`
--
ALTER TABLE `user_accounts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cards_on_edit`
--
ALTER TABLE `cards_on_edit`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id - записи', AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `districts`
--
ALTER TABLE `districts`
  MODIFY `id` smallint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id - записи', AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT для таблицы `genders`
--
ALTER TABLE `genders`
  MODIFY `id` tinyint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id - Записи', AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `insurance_companies`
--
ALTER TABLE `insurance_companies`
  MODIFY `id` tinyint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id - записи', AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `localities`
--
ALTER TABLE `localities`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id - записи', AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT для таблицы `refresh_tokens`
--
ALTER TABLE `refresh_tokens`
  MODIFY `id` smallint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id - записи', AUTO_INCREMENT=961;

--
-- AUTO_INCREMENT для таблицы `regions`
--
ALTER TABLE `regions`
  MODIFY `id` tinyint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id - записи', AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT для таблицы `streets`
--
ALTER TABLE `streets`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id - записи', AUTO_INCREMENT=13;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `districts`
--
ALTER TABLE `districts`
  ADD CONSTRAINT `districts_ibfk_1` FOREIGN KEY (`region`) REFERENCES `regions` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `localities`
--
ALTER TABLE `localities`
  ADD CONSTRAINT `localities_ibfk_1` FOREIGN KEY (`district`) REFERENCES `districts` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `patient_cards`
--
ALTER TABLE `patient_cards`
  ADD CONSTRAINT `patient_cards_ibfk_1` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `patient_cards_ibfk_2` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `patient_cards_ibfk_3` FOREIGN KEY (`street_id`) REFERENCES `streets` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `patient_cards_ibfk_4` FOREIGN KEY (`locality_id`) REFERENCES `localities` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `patient_cards_ibfk_5` FOREIGN KEY (`street_id`) REFERENCES `streets` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `patient_cards_ibfk_6` FOREIGN KEY (`insurance_company_id`) REFERENCES `insurance_companies` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `patient_cards_ibfk_7` FOREIGN KEY (`owner`) REFERENCES `user_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `patient_cards_ibfk_8` FOREIGN KEY (`gender`) REFERENCES `genders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
